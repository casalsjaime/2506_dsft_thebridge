-- claustros que sean TA

SELECT * FROM claustro WHERE rol = 'TA';