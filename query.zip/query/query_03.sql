-- lista de cursos con modalidad online

SELECT * FROM curso WHERE modalidad = 'Online';