-- lista de alumnos ordenados por nombre de A-Z

SELECT * FROM alumno ORDER BY nombre;