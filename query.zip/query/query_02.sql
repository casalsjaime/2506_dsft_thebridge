-- dime el correo de Anita Heredia

SELECT email FROM alumno WHERE nombre = 'Anita Heredia';