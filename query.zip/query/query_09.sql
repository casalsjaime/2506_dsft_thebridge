-- numero total de alumnos

SELECT COUNT(*) AS total_alumnos FROM alumno;